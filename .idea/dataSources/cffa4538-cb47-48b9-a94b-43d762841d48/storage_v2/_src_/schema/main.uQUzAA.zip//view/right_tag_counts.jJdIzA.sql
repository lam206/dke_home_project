CREATE VIEW right_tag_counts
AS SELECT tag_label, count(*) as count_right
	FROM Tags
	JOIN Tweets ON Tags.tweet_id = Tweets.tweet_id
	WHERE left_leaning = 0
	GROUP BY tag_label;

