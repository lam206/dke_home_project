CREATE VIEW factors
AS SELECT * FROM factors_for_common_tags UNION
	SELECT * FROM factors_for_left_tags UNION
	SELECT * FROM factors_for_right_tags;

