CREATE VIEW factors_users
AS SELECT * FROM factors_for_common_users UNION
	SELECT * FROM factors_for_left_users UNION
	SELECT * FROM factors_for_right_users;

