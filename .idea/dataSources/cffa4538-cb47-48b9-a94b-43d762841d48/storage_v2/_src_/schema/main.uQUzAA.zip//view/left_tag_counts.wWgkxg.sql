CREATE VIEW left_tag_counts
AS SELECT tag_label, count(*) as count_left
	FROM Tags
	JOIN Tweets ON Tags.tweet_id = Tweets.tweet_id
	WHERE left_leaning = 1
	GROUP BY tag_label;

