CREATE VIEW right_user_counts
AS SELECT user, count(*) as count_right
	FROM Entities
	JOIN Tweets ON Entities.tweet_id = Tweets.tweet_id
	WHERE left_leaning = 0
	GROUP BY user;

