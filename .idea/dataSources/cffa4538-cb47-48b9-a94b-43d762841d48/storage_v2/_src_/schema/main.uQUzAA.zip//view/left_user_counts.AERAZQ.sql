CREATE VIEW left_user_counts
AS SELECT user, count(*) as count_left
	FROM Entities
	JOIN Tweets ON Entities.tweet_id = Tweets.tweet_id
	WHERE left_leaning = 1
	GROUP BY user;

