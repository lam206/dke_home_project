CREATE VIEW factors_for_right_tags
AS SELECT
		tag_label, - (CAST(count_right AS float) + 1.0) AS factor, count_right As total_tag_mentions
	FROM right_tag_counts
	WHERE tag_label not in (select distinct tag_label from left_tag_counts);

