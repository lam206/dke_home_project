CREATE VIEW factors_for_common_tags
AS SELECT
		t1.tag_label AS tag_label,
		IIF(count_right > count_left,
			- (CAST(count_right AS float) + 1.0) / (CAST(count_left AS float) + 1.0),
			(CAST(count_left AS float) + 1.0) / (CAST(count_right AS float) + 1.0)) AS factor,
		count_right + count_left AS total_tag_mentions
	FROM
		left_tag_counts as t1
	JOIN
		right_tag_counts as t2
	ON t1.tag_label = t2.tag_label;

