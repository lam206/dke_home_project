CREATE VIEW factors_for_left_users
AS SELECT
		user, (CAST(count_left AS float) + 1.0) AS factor, count_left As total_user_mentions
	FROM left_user_counts
	WHERE user not in (select distinct user from right_user_counts);

