CREATE VIEW TweetsWithFactorSum AS
    SELECT Tags.tweet_id, sum(f.factor), left_leaning
    FROM Tweets
    JOIN Tags ON Tags.tweet_id = Tweets.tweet_id
    JOIN factors f on Tags.tag_label = f.tag_label
    group by Tweets.tweet_id;

