CREATE VIEW factors_for_left_tags
AS SELECT
		tag_label, CAST(count_left AS float) + 1.0 AS factor, count_left AS total_tag_mentions
	FROM left_tag_counts
	WHERE tag_label not in (select distinct tag_label from right_tag_counts);

