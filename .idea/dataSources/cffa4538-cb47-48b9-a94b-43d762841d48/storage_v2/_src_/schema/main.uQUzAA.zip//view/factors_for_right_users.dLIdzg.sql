CREATE VIEW factors_for_right_users
AS SELECT
		user, - (CAST(count_right AS float) + 1.0) AS factor, count_right As total_user_mentions
	FROM right_user_counts
	WHERE user not in (select distinct user from left_user_counts);

